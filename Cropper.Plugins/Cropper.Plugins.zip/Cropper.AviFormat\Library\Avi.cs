/* This class has been written by
 * Corinna John (Hannover, Germany)
 * cj@binary-universe.net
 * 
 * You may do with this code whatever you like,
 * except selling it or claiming any rights/ownership.
 * 
 * Please send me a little feedback about what you're
 * using this code for and what changes you'd like to
 * see in later versions. (And please excuse my bad english.)
 * 
 * WARNING: This is experimental code.
 * Please do not expect "Release Quality".
 * */

using System;
using System.Runtime.InteropServices;

namespace AviFile
{
	internal class Avi
	{
		public static int PALETTE_SIZE = 4*256; //RGBQUAD * 256 colours

		public static readonly int streamtypeVIDEO = mmioFOURCC('v', 'i', 'd', 's');
		public static readonly int streamtypeAUDIO = mmioFOURCC('a', 'u', 'd', 's');
		public static readonly int streamtypeMIDI = mmioFOURCC('m', 'i', 'd', 's');
		public static readonly int streamtypeTEXT = mmioFOURCC('t', 'x', 't', 's');

		public const int OF_SHARE_DENY_WRITE = 32;
		public const int OF_WRITE = 1;
		public const int OF_READWRITE = 2;
		public const int OF_CREATE = 4096;

		public const int BMP_MAGIC_COOKIE = 19778; //ascii string "BM"

		public const int AVICOMPRESSF_INTERLEAVE = 0x00000001; // interleave
		public const int AVICOMPRESSF_DATARATE = 0x00000002; // use a data rate
		public const int AVICOMPRESSF_KEYFRAMES = 0x00000004; // use keyframes
		public const int AVICOMPRESSF_VALID = 0x00000008; // has valid data
		public const int AVIIF_KEYFRAME = 0x00000010;

		public const UInt32 ICMF_CHOOSE_KEYFRAME = 0x0001; // show KeyFrame Every box
		public const UInt32 ICMF_CHOOSE_DATARATE = 0x0002; // show DataRate box
		public const UInt32 ICMF_CHOOSE_PREVIEW = 0x0004; // allow expanded preview dialog

		//macro mmioFOURCC
		public static Int32 mmioFOURCC(char ch0, char ch1, char ch2, char ch3)
		{
			return ((Int32) (byte) (ch0) | ((Int32) (byte) (ch1) << 8) |
			        ((Int32) (byte) (ch2) << 16) | ((Int32) (byte) (ch3) << 24));
		}

		#region structure declarations

		[StructLayout(LayoutKind.Sequential, Pack=1)]
		public struct RECT
		{
			public UInt32 left;
			public UInt32 top;
			public UInt32 right;
			public UInt32 bottom;
		}

		[StructLayout(LayoutKind.Sequential, Pack=1)]
		public struct BITMAPINFOHEADER
		{
			public Int32 biSize;
			public Int32 biWidth;
			public Int32 biHeight;
			public Int16 biPlanes;
			public Int16 biBitCount;
			public Int32 biCompression;
			public Int32 biSizeImage;
			public Int32 biXPelsPerMeter;
			public Int32 biYPelsPerMeter;
			public Int32 biClrUsed;
			public Int32 biClrImportant;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct PCMWAVEFORMAT
		{
			public short wFormatTag;
			public short nChannels;
			public int nSamplesPerSec;
			public int nAvgBytesPerSec;
			public short nBlockAlign;
			public short wBitsPerSample;
			public short cbSize;
		}

		[StructLayout(LayoutKind.Sequential, Pack=1)]
		public struct AVISTREAMINFO
		{
			public Int32 fccType;
			public Int32 fccHandler;
			public Int32 dwFlags;
			public Int32 dwCaps;
			public Int16 wPriority;
			public Int16 wLanguage;
			public Int32 dwScale;
			public Int32 dwRate;
			public Int32 dwStart;
			public Int32 dwLength;
			public Int32 dwInitialFrames;
			public Int32 dwSuggestedBufferSize;
			public Int32 dwQuality;
			public Int32 dwSampleSize;
			public RECT rcFrame;
			public Int32 dwEditCount;
			public Int32 dwFormatChangeCount;

			[MarshalAs(UnmanagedType.ByValArray, SizeConst=64)] public UInt16[] szName;
		}

		[StructLayout(LayoutKind.Sequential, Pack=1)]
		public struct BITMAPFILEHEADER
		{
			public Int16 bfType; //"magic cookie" - must be "BM"
			public Int32 bfSize;
			public Int16 bfReserved1;
			public Int16 bfReserved2;
			public Int32 bfOffBits;
		}

		[StructLayout(LayoutKind.Sequential, Pack=1)]
		public struct AVIFILEINFO
		{
			public Int32 dwMaxBytesPerSecond;
			public Int32 dwFlags;
			public Int32 dwCaps;
			public Int32 dwStreams;
			public Int32 dwSuggestedBufferSize;
			public Int32 dwWidth;
			public Int32 dwHeight;
			public Int32 dwScale;
			public Int32 dwRate;
			public Int32 dwLength;
			public Int32 dwEditCount;

			[MarshalAs(UnmanagedType.ByValArray, SizeConst=64)] public char[] szFileType;
		}

		[StructLayout(LayoutKind.Sequential, Pack=1)]
		public struct AVICOMPRESSOPTIONS
		{
			public UInt32 fccType;
			public UInt32 fccHandler;
			public UInt32 dwKeyFrameEvery; // only used with AVICOMRPESSF_KEYFRAMES
			public UInt32 dwQuality;
			public UInt32 dwBytesPerSecond; // only used with AVICOMPRESSF_DATARATE
			public UInt32 dwFlags;
			public IntPtr lpFormat;
			public UInt32 cbFormat;
			public IntPtr lpParms;
			public UInt32 cbParms;
			public UInt32 dwInterleaveEvery;
		}

		/// <summary>AviSaveV needs a pointer to a pointer to an AVICOMPRESSOPTIONS structure</summary>
		[StructLayout(LayoutKind.Sequential, Pack=1)]
		public class AVICOMPRESSOPTIONS_CLASS
		{
			public UInt32 fccType;
			public UInt32 fccHandler;
			public UInt32 dwKeyFrameEvery; // only used with AVICOMRPESSF_KEYFRAMES
			public UInt32 dwQuality;
			public UInt32 dwBytesPerSecond; // only used with AVICOMPRESSF_DATARATE
			public UInt32 dwFlags;
			public IntPtr lpFormat;
			public UInt32 cbFormat;
			public IntPtr lpParms;
			public UInt32 cbParms;
			public UInt32 dwInterleaveEvery;

			public AVICOMPRESSOPTIONS ToStruct()
			{
				AVICOMPRESSOPTIONS returnVar = new AVICOMPRESSOPTIONS();
				returnVar.fccType = fccType;
				returnVar.fccHandler = fccHandler;
				returnVar.dwKeyFrameEvery = dwKeyFrameEvery;
				returnVar.dwQuality = dwQuality;
				returnVar.dwBytesPerSecond = dwBytesPerSecond;
				returnVar.dwFlags = dwFlags;
				returnVar.lpFormat = lpFormat;
				returnVar.cbFormat = cbFormat;
				returnVar.lpParms = lpParms;
				returnVar.cbParms = cbParms;
				returnVar.dwInterleaveEvery = dwInterleaveEvery;
				return returnVar;
			}
		}

		#endregion structure declarations

		#region method declarations

		//Initialize the AVI library
		[DllImport("avifil32.dll")]
		public static extern void AVIFileInit();

		//Open an AVI file
		[DllImport("avifil32.dll", PreserveSig=true)]
		public static extern int AVIFileOpen(
			ref int ppfile,
			String szFile,
			int uMode,
			int pclsidHandler);

		//Get a stream from an open AVI file
		[DllImport("avifil32.dll")]
		public static extern int AVIFileGetStream(
			int pfile,
			out IntPtr ppavi,
			int fccType,
			int lParam);

		//Get the start position of a stream
		[DllImport("avifil32.dll", PreserveSig=true)]
		public static extern int AVIStreamStart(int pavi);

		//Get the length of a stream in frames
		[DllImport("avifil32.dll", PreserveSig=true)]
		public static extern int AVIStreamLength(int pavi);

		//Get information about an open stream
		[DllImport("avifil32.dll")]
		public static extern int AVIStreamInfo(
			int pAVIStream,
			ref AVISTREAMINFO psi,
			int lSize);

		//Get a pointer to a GETFRAME object (returns 0 on error)
		[DllImport("avifil32.dll")]
		public static extern int AVIStreamGetFrameOpen(
			IntPtr pAVIStream,
			ref BITMAPINFOHEADER bih);

		//Get a pointer to a packed DIB (returns 0 on error)
		[DllImport("avifil32.dll")]
		public static extern int AVIStreamGetFrame(
			int pGetFrameObj,
			int lPos);

		//Create a new stream in an open AVI file
		[DllImport("avifil32.dll")]
		public static extern int AVIFileCreateStream(
			int pfile,
			out IntPtr ppavi,
			ref AVISTREAMINFO ptr_streaminfo);

		//Set the format for a new stream
		[DllImport("avifil32.dll")]
		public static extern int AVIStreamSetFormat(
			IntPtr aviStream, Int32 lPos,
			ref BITMAPINFOHEADER lpFormat, Int32 cbFormat);

		//Set the format for a new stream
		[DllImport("avifil32.dll")]
		public static extern int AVIStreamSetFormat(
			IntPtr aviStream, Int32 lPos,
			ref PCMWAVEFORMAT lpFormat, Int32 cbFormat);

		//Read the format for a stream
		[DllImport("avifil32.dll")]
		public static extern int AVIStreamReadFormat(
			IntPtr aviStream, Int32 lPos,
			ref BITMAPINFOHEADER lpFormat, ref Int32 cbFormat
			);

		//Read the size of the format for a stream
		[DllImport("avifil32.dll")]
		public static extern int AVIStreamReadFormat(
			IntPtr aviStream, Int32 lPos,
			int empty, ref Int32 cbFormat
			);

		//Read the format for a stream
		[DllImport("avifil32.dll")]
		public static extern int AVIStreamReadFormat(
			IntPtr aviStream, Int32 lPos,
			ref PCMWAVEFORMAT lpFormat, ref Int32 cbFormat
			);

		//Write a sample to a stream
		[DllImport("avifil32.dll")]
		public static extern int AVIStreamWrite(
			IntPtr aviStream, Int32 lStart, Int32 lSamples,
			IntPtr lpBuffer, Int32 cbBuffer, Int32 dwFlags,
			Int32 dummy1, Int32 dummy2);

		//Release the GETFRAME object
		[DllImport("avifil32.dll")]
		public static extern int AVIStreamGetFrameClose(
			int pGetFrameObj);

		//Release an open AVI stream
		[DllImport("avifil32.dll")]
		public static extern int AVIStreamRelease(IntPtr aviStream);

		//Release an open AVI file
		[DllImport("avifil32.dll")]
		public static extern int AVIFileRelease(int pfile);

		//Close the AVI library
		[DllImport("avifil32.dll")]
		public static extern void AVIFileExit();

		[DllImport("avifil32.dll")]
		public static extern int AVIMakeCompressedStream(
			out IntPtr ppsCompressed, IntPtr aviStream,
			ref AVICOMPRESSOPTIONS ao, int dummy);

		[DllImport("avifil32.dll")]
		public static extern bool AVISaveOptions(
			IntPtr hwnd,
			UInt32 uiFlags,
			Int32 nStreams,
			ref IntPtr ppavi,
			ref AVICOMPRESSOPTIONS_CLASS plpOptions
			);

		[DllImport("avifil32.dll")]
		public static extern long AVISaveOptionsFree(
			int nStreams,
			ref AVICOMPRESSOPTIONS_CLASS plpOptions
			);

		[DllImport("avifil32.dll")]
		public static extern int AVIFileInfo(
			int pfile,
			ref AVIFILEINFO pfi,
			int lSize);

		[DllImport("winmm.dll", EntryPoint="mmioStringToFOURCCA")]
		public static extern int mmioStringToFOURCC(String sz, int uFlags);

		[DllImport("avifil32.dll")]
		public static extern int AVIStreamRead(
			IntPtr pavi,
			Int32 lStart,
			Int32 lSamples,
			IntPtr lpBuffer,
			Int32 cbBuffer,
			Int32 plBytes,
			Int32 plSamples
			);

		[DllImport("avifil32.dll")]
		public static extern int CreateEditableStream(
			out IntPtr ppsEditable,
			IntPtr psSource
			);

		[DllImport("avifil32.dll")]
		public static extern int AVISaveV(
			String szFile,
			Int16 empty,
			Int16 lpfnCallback,
			Int16 nStreams,
			ref IntPtr ppavi,
			ref AVICOMPRESSOPTIONS_CLASS plpOptions
			);

		#endregion method declarations
	}
}