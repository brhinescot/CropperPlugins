namespace CropperPlugins
{
    public enum EmailOutputFormat
    {
        Bitmap,
        Jpg,
        Png
    }
}