using System.Reflection;
using System.Resources;
using System.Security.Permissions;
[assembly : SecurityPermission(SecurityAction.RequestMinimum, UnmanagedCode=false)]
[assembly : AssemblyTitle("Cropper.AviFormat")]
[assembly : AssemblyDefaultAlias("Cropper.AviFormat")]
[assembly : AssemblyDescription("Cropper.AviFormat")]
[assembly : AssemblyConfiguration("Cropper")]
[assembly : AssemblyCompany("Fusion8 Design")]
[assembly : AssemblyProduct("Cropper")]
[assembly : AssemblyCopyright("Copyright 2004 Brian Scott (Fusion8 Design). All rights reserved.")]
[assembly : AssemblyTrademark("")]
[assembly : AssemblyCulture("")]
[assembly : AssemblyVersion("0.9.0.0")]
[assembly : NeutralResourcesLanguage("en-US")]