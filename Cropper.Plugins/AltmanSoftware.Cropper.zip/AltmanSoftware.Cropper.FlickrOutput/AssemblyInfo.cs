// Assembly AltmanSoftware.Cropper.FlickrOutput, Version 1.8.0.38266

[assembly: System.Reflection.AssemblyVersion("1.8.0.38266")]
[assembly: System.Reflection.AssemblyKeyName("")]
[assembly: System.Reflection.AssemblyKeyFile("")]
[assembly: System.Reflection.AssemblyDelaySign(false)]
[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Reflection.AssemblyCopyright("")]
[assembly: System.Reflection.AssemblyProduct("")]
[assembly: System.Reflection.AssemblyCompany("Altman Software")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyDescription("A plugin for the Cropper screen shot tool integrates with a Flickr account, uploaded the image automatically.")]
[assembly: System.Reflection.AssemblyTitle("Cropper Flickr Plugin")]

